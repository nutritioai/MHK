# NutriAI

AI-powered calorie calculator and personalized diet planner.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy to Vercel

Import this repository into Vercel. The default Vite settings are:

- Build Command: `npm run build`
- Output Directory: `dist`

The app currently has a local nutrition fallback so the UI can be tested without an AI API.

For production AI, configure a secure server-side endpoint. Never expose an AI provider secret key in browser code.

## Planned production integrations

- Supabase authentication/database
- Secure AI API route
- Saudi-compatible subscription/payment gateway
- Production food/nutrition data source
