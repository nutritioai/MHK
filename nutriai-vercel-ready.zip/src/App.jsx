import React, { useState, useEffect, useRef, useCallback } from "react";

/* =========================================================
   COPY / TRANSLATIONS
========================================================= */
const T = {
  en: {
    dir: "ltr", brand: "NutriAI", tagline: "Eat Smart. Track Better. Live Healthier.",
    nav: { home: "Home", dash: "Dashboard", calc: "Calculator", plan: "Diet Plan", assistant: "AI Assistant", pricing: "Pricing" },
    heroTitle: "Your AI Nutrition & Calorie Coach",
    heroSub: "Calculate calories, build personalized meal plans and reach your health goals with AI.",
    heroCta: "Get Started", heroCta2: "See Plans",
    disclaimer: "Nutrition information is estimated and should not replace professional medical or dietary advice.",
    features: {
      title: "Everything you need to eat smarter",
      items: [
        { t: "AI Food Calculator", d: "Describe any Arabian or international dish and get instant calories & macros." },
        { t: "Personalized Diet Plans", d: "AI builds a daily meal plan around your goals, calories and preferences." },
        { t: "Daily Tracking", d: "Log meals, track water, and watch your progress toward your target." },
      ],
    },
    faq: {
      title: "Frequently asked questions",
      items: [
        { q: "Is the calorie data accurate?", a: "Values are AI-generated estimates. Actual calories vary by recipe, brand and portion — use them as a guide, not an exact measurement." },
        { q: "Can I use it in Arabic?", a: "Yes — switch languages anytime from the top bar. The whole interface, including AI responses, adapts." },
        { q: "Can I cancel anytime?", a: "Yes, subscriptions are monthly with no long-term commitment." },
      ],
    },
    onboard: {
      title: "Let's set up your profile",
      sub: "This takes less than a minute and powers your personalized targets.",
      name: "Name", age: "Age", gender: "Gender", male: "Male", female: "Female",
      height: "Height (cm)", weight: "Weight (kg)", activity: "Activity level",
      activityOpts: ["Sedentary", "Lightly active", "Moderately active", "Very active", "Extremely active"],
      goal: "Goal", goalOpts: ["Lose weight", "Maintain weight", "Gain weight", "Build muscle"],
      targetWeight: "Target weight (kg)", diet: "Dietary preference",
      dietOpts: ["No preference", "Vegetarian", "Vegan", "Keto", "Halal", "Low-carb"],
      allergies: "Allergies (optional)", allergiesPh: "e.g. peanuts, shellfish",
      meals: "Meals per day", submit: "Create my profile",
    },
    dash: {
      title: "Today's overview", consumed: "Consumed", remaining: "Remaining", goal: "Daily goal",
      protein: "Protein", carbs: "Carbs", fat: "Fat", water: "Water", glasses: "glasses",
      mealsToday: "Today's meals", noMeals: "No meals logged yet — try the AI Calculator.",
      yourTargets: "Your daily targets", bmr: "BMR", tdee: "TDEE",
    },
    calc: {
      title: "AI Food Calculator", sub: "Describe any dish — Arabian or international — and let AI estimate it.",
      placeholder: "e.g. Chicken mandi with rice, or a slice of knafeh…",
      button: "Calculate", loading: "Thinking…", arabian: "Arabian", intl: "International",
      resultTitle: "Estimated nutrition", calories: "Calories", serving: "Per serving",
      note: "AI-generated estimate — actual values vary by recipe and portion.",
      errorGeneric: "AI service is temporarily unavailable. Please try again.",
      tryExamples: "Try:", examples: ["Kabsa with lamb", "Falafel wrap", "Sushi platter", "Knafeh"],
      addToday: "Add to today", added: "Added ✓", selectMeal: "Log as",
      mealOpts: ["Breakfast", "Lunch", "Dinner", "Snack"],
    },
    plan: {
      title: "AI Diet Plan Generator", sub: "Built around your profile — calories, goal and preferences.",
      generate: "Generate my diet plan", regenerate: "Regenerate", loading: "Building your plan…",
      save: "Save plan", saved: "Saved ✓", dailyTotal: "Daily total",
      needProfile: "Complete your profile first to generate a personalized plan.",
      goProfile: "Set up profile",
    },
    assistant: {
      title: "NutriAI Assistant", sub: "Ask about calories, meals or your plan.",
      placeholder: "Ask NutriAI anything about food or nutrition…", send: "Send",
      safety: "NutriAI provides general nutrition information and is not a substitute for professional medical advice.",
      starterQs: ["How many calories are in Kabsa?", "Suggest a high-protein breakfast", "Healthy alternative to Shawarma?"],
    },
    pricing: {
      title: "Simple, honest pricing", sub: "Start free. Upgrade anytime.", perMonth: "/ month", recommended: "Recommended",
      free: { name: "Free", price: "SAR 0", desc: "Basic essentials", cta: "Start free",
        features: ["Limited food database (bread, rice, eggs, milk, chicken, fruit)", "Basic calorie calculator", "Basic daily tracking", "Limited AI requests"] },
      premium: { name: "Premium", price: "SAR 29", desc: "Full AI nutrition experience", cta: "Upgrade to Premium",
        features: ["Full Arabian + international food database", "Unlimited AI food calculator", "AI diet plan generator", "Water & macro tracking", "Weekly reports", "No ads"] },
      plus: { name: "Premium Plus", price: "SAR 59", desc: "Advanced planning & analytics", cta: "Choose Premium Plus",
        features: ["Everything in Premium", "Custom weekly meal plans", "Grocery list generation", "Meal substitutions", "Advanced analytics", "Priority AI processing"] },
    },
    locked: "Unlock with Premium",
    footerNote: "Nutrition information is estimated and should not replace professional medical or dietary advice.",
    langToggle: "العربية",
  },
  ar: {
    dir: "rtl", brand: "نيوتري AI", tagline: "كُل بذكاء، تتبّع بشكل أفضل، وعِش بصحة أفضل.",
    nav: { home: "الرئيسية", dash: "لوحتي", calc: "الحاسبة", plan: "خطة الغذاء", assistant: "المساعد الذكي", pricing: "الأسعار" },
    heroTitle: "مدربك الذكي للتغذية والسعرات الحرارية",
    heroSub: "احسب السعرات، وابنِ خطط وجبات مخصصة، وحقّق أهدافك الصحية بمساعدة الذكاء الاصطناعي.",
    heroCta: "ابدأ الآن", heroCta2: "شاهد الباقات",
    disclaimer: "المعلومات الغذائية تقديرية ولا تغني عن الاستشارة الطبية أو الغذائية المتخصصة.",
    features: {
      title: "كل ما تحتاجه لتأكل بذكاء",
      items: [
        { t: "حاسبة الطعام الذكية", d: "صف أي طبق عربي أو عالمي واحصل فورًا على السعرات والقيم الغذائية." },
        { t: "خطط غذائية مخصصة", d: "يبني الذكاء الاصطناعي خطة يومية حسب أهدافك وسعراتك وتفضيلاتك." },
        { t: "تتبع يومي", d: "سجّل وجباتك، تابع كمية الماء، وراقب تقدمك نحو هدفك." },
      ],
    },
    faq: {
      title: "الأسئلة الشائعة",
      items: [
        { q: "هل بيانات السعرات دقيقة؟", a: "القيم تقديرات يولّدها الذكاء الاصطناعي. القيم الفعلية تختلف حسب الوصفة والعلامة التجارية والحصة — استخدمها كدليل وليست قياسًا دقيقًا." },
        { q: "هل يمكنني استخدامه بالعربية؟", a: "نعم — بدّل اللغة في أي وقت من الأعلى. الواجهة كاملة، بما فيها ردود الذكاء الاصطناعي، تتكيّف معك." },
        { q: "هل يمكن الإلغاء في أي وقت؟", a: "نعم، الاشتراكات شهرية بدون التزام طويل الأمد." },
      ],
    },
    onboard: {
      title: "لنقم بإعداد ملفك الشخصي",
      sub: "يستغرق أقل من دقيقة ويحدد أهدافك المخصصة.",
      name: "الاسم", age: "العمر", gender: "الجنس", male: "ذكر", female: "أنثى",
      height: "الطول (سم)", weight: "الوزن (كجم)", activity: "مستوى النشاط",
      activityOpts: ["خامل", "نشاط خفيف", "نشاط متوسط", "نشاط عالٍ", "نشاط عالٍ جدًا"],
      goal: "الهدف", goalOpts: ["خسارة الوزن", "الحفاظ على الوزن", "زيادة الوزن", "بناء العضلات"],
      targetWeight: "الوزن المستهدف (كجم)", diet: "التفضيل الغذائي",
      dietOpts: ["بدون تفضيل", "نباتي", "نباتي صرف", "كيتو", "حلال", "قليل الكربوهيدرات"],
      allergies: "الحساسية (اختياري)", allergiesPh: "مثال: الفول السوداني، المحار",
      meals: "عدد الوجبات يوميًا", submit: "إنشاء ملفي",
    },
    dash: {
      title: "نظرة اليوم", consumed: "المستهلك", remaining: "المتبقي", goal: "الهدف اليومي",
      protein: "البروتين", carbs: "الكربوهيدرات", fat: "الدهون", water: "الماء", glasses: "أكواب",
      mealsToday: "وجبات اليوم", noMeals: "لم يتم تسجيل أي وجبة بعد — جرّب الحاسبة الذكية.",
      yourTargets: "أهدافك اليومية", bmr: "معدل الأيض الأساسي", tdee: "إجمالي الطاقة اليومية",
    },
    calc: {
      title: "حاسبة الطعام الذكية", sub: "صف أي طبق — عربي أو عالمي — ودع الذكاء الاصطناعي يقدّره.",
      placeholder: "مثال: مندي دجاج مع الأرز، أو قطعة كنافة…",
      button: "احسب", loading: "جارٍ التفكير…", arabian: "عربي", intl: "عالمي",
      resultTitle: "القيمة الغذائية المقدّرة", calories: "السعرات", serving: "لكل حصة",
      note: "تقدير مُولَّد بالذكاء الاصطناعي — القيم الفعلية تختلف حسب الوصفة والحصة.",
      errorGeneric: "خدمة الذكاء الاصطناعي غير متاحة مؤقتًا. حاول مرة أخرى.",
      tryExamples: "جرّب:", examples: ["كبسة لحم", "لفافة فلافل", "طبق سوشي", "كنافة"],
      addToday: "أضف لليوم", added: "أُضيف ✓", selectMeal: "سجّل كـ",
      mealOpts: ["الفطور", "الغداء", "العشاء", "وجبة خفيفة"],
    },
    plan: {
      title: "مولّد خطة الغذاء الذكي", sub: "مبنية حسب ملفك الشخصي — السعرات والهدف والتفضيلات.",
      generate: "أنشئ خطتي الغذائية", regenerate: "إعادة الإنشاء", loading: "جارٍ بناء خطتك…",
      save: "حفظ الخطة", saved: "تم الحفظ ✓", dailyTotal: "الإجمالي اليومي",
      needProfile: "أكمل ملفك الشخصي أولًا لإنشاء خطة مخصصة.",
      goProfile: "إعداد الملف الشخصي",
    },
    assistant: {
      title: "مساعد نيوتري الذكي", sub: "اسأل عن السعرات أو الوجبات أو خطتك.",
      placeholder: "اسأل عن أي شيء يخص الطعام أو التغذية…", send: "إرسال",
      safety: "يقدّم المساعد معلومات غذائية عامة ولا يغني عن استشارة طبية متخصصة.",
      starterQs: ["كم سعرة حرارية في الكبسة؟", "اقترح فطورًا غنيًا بالبروتين", "بديل صحي للشاورما؟"],
    },
    pricing: {
      title: "أسعار بسيطة وواضحة", sub: "ابدأ مجانًا، وارتقِ في أي وقت.", perMonth: "/ شهريًا", recommended: "الأكثر طلبًا",
      free: { name: "مجانية", price: "٠ ريال", desc: "الأساسيات فقط", cta: "ابدأ مجانًا",
        features: ["قاعدة طعام محدودة (خبز، أرز، بيض، حليب، دجاج، فواكه)", "حاسبة سعرات أساسية", "تتبع يومي أساسي", "طلبات ذكاء اصطناعي محدودة"] },
      premium: { name: "بريميوم", price: "٢٩ ريال", desc: "تجربة تغذية ذكية كاملة", cta: "الترقية إلى بريميوم",
        features: ["قاعدة بيانات عربية وعالمية كاملة", "حاسبة ذكاء اصطناعي غير محدودة", "مولّد خطة غذائية ذكي", "تتبع الماء والقيم الغذائية", "تقارير أسبوعية", "بدون إعلانات"] },
      plus: { name: "بريميوم بلس", price: "٥٩ ريال", desc: "تخطيط وتحليلات متقدمة", cta: "اختر بريميوم بلس",
        features: ["كل ما في بريميوم", "خطط وجبات أسبوعية مخصصة", "قوائم تسوق تلقائية", "بدائل للوجبات", "تحليلات متقدمة", "أولوية معالجة الذكاء الاصطناعي"] },
    },
    locked: "افتح مع بريميوم",
    footerNote: "المعلومات الغذائية تقديرية ولا تغني عن الاستشارة الطبية أو الغذائية المتخصصة.",
    langToggle: "English",
  },
};

const IMG = {
  hero: "https://images.unsplash.com/photo-1547573854-74d2a71d0826?q=80&w=1200&auto=format&fit=crop",
  kabsa: "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?q=80&w=500&auto=format&fit=crop",
  intl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=500&auto=format&fit=crop",
  sweets: "https://images.unsplash.com/photo-1519676867240-f03562e64548?q=80&w=500&auto=format&fit=crop",
};

/* =========================================================
   AI HELPERS
========================================================= */
/*
  AI gateway:
  - If you configure window.NUTRIAI_CONFIG.aiEndpoint, requests go to your
    secure server/backend.
  - Never put an Anthropic/OpenAI secret key in this frontend.
  - The local fallback keeps the demo fully usable when no backend exists.
*/
async function callClaude(system, userContent) {
  const endpoint = window.NUTRIAI_CONFIG?.aiEndpoint || import.meta.env.VITE_AI_ENDPOINT;
  if (endpoint) {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ system, message: userContent }),
    });
    if (!response.ok) throw new Error("AI backend error");
    const data = await response.json();
    return data.text || data.output || JSON.stringify(data);
  }
  throw new Error("AI backend not configured");
}

const LOCAL_FOODS = [
  { names:["bread","arabic bread","khubz","خبز","خبز عربي"], dish:"Arabic Bread", calories:165, protein_g:5.5, carbs_g:33, fat_g:1, serving:"1 small piece (60g)" },
  { names:["rice","white rice","أرز","رز"], dish:"Cooked White Rice", calories:205, protein_g:4.3, carbs_g:44.5, fat_g:0.4, serving:"1 cup (158g)" },
  { names:["egg","eggs","بيض"], dish:"Eggs", calories:78, protein_g:6.3, carbs_g:0.6, fat_g:5.3, serving:"1 large egg" },
  { names:["chicken breast","دجاج","صدر دجاج"], dish:"Chicken Breast", calories:284, protein_g:53, carbs_g:0, fat_g:6.2, serving:"1 cooked breast (170g)" },
  { names:["milk","حليب"], dish:"Whole Milk", calories:149, protein_g:7.7, carbs_g:11.7, fat_g:8, serving:"1 cup (244ml)" },
  { names:["apple","تفاح"], dish:"Apple", calories:95, protein_g:0.5, carbs_g:25, fat_g:0.3, serving:"1 medium apple" },
  { names:["banana","موز"], dish:"Banana", calories:105, protein_g:1.3, carbs_g:27, fat_g:0.4, serving:"1 medium banana" },
  { names:["dates","date","تمر"], dish:"Dates", calories:66, protein_g:0.4, carbs_g:18, fat_g:0.1, serving:"2 dates (48g)" },
  { names:["hummus","حمص"], dish:"Hummus", calories:166, protein_g:7.9, carbs_g:14.3, fat_g:9.6, serving:"100g" },
  { names:["falafel","فلافل"], dish:"Falafel", calories:333, protein_g:13.3, carbs_g:31.8, fat_g:17.8, serving:"100g" },
  { names:["shawarma","شاورما"], dish:"Chicken Shawarma", calories:260, protein_g:18, carbs_g:18, fat_g:12, serving:"1 sandwich" },
  { names:["kabsa","كبسة"], dish:"Chicken Kabsa", calories:620, protein_g:38, carbs_g:62, fat_g:22, serving:"1 plate (approx.)" },
  { names:["mandi","مندي"], dish:"Chicken Mandi", calories:650, protein_g:40, carbs_g:65, fat_g:23, serving:"1 plate (approx.)" },
  { names:["knafeh","kunafa","كنافة"], dish:"Knafeh", calories:410, protein_g:9, carbs_g:52, fat_g:19, serving:"1 piece (100g)" },
  { names:["pizza","بيتزا"], dish:"Cheese Pizza", calories:285, protein_g:12, carbs_g:36, fat_g:10, serving:"1 slice" },
  { names:["burger","برجر"], dish:"Beef Burger", calories:520, protein_g:27, carbs_g:35, fat_g:30, serving:"1 burger" },
  { names:["pasta","مكرونة"], dish:"Pasta with Tomato Sauce", calories:330, protein_g:11, carbs_g:58, fat_g:7, serving:"1.5 cups" },
  { names:["salmon","سمك سلمون"], dish:"Salmon", calories:208, protein_g:20, carbs_g:0, fat_g:13, serving:"100g" },
  { names:["oatmeal","oats","شوفان"], dish:"Oatmeal", calories:307, protein_g:10.7, carbs_g:54, fat_g:5.3, serving:"1 cup cooked" },
];

function findLocalFood(query) {
  const q = query.toLowerCase().trim();
  return LOCAL_FOODS.find(f => f.names.some(n => q.includes(n.toLowerCase()) || n.toLowerCase().includes(q)));
}

function localFoodEstimate(dish) {
  const found = findLocalFood(dish);
  if (found) return { ...found };
  const q = dish.toLowerCase();
  let calories = 350, protein_g = 18, carbs_g = 38, fat_g = 14;
  if (q.includes("chicken") || q.includes("دجاج")) { calories = 420; protein_g = 35; carbs_g = 28; fat_g = 18; }
  if (q.includes("lamb") || q.includes("لحم") || q.includes("lحم")) { calories = 520; protein_g = 30; carbs_g = 35; fat_g = 27; }
  if (q.includes("salad") || q.includes("سلطة")) { calories = 180; protein_g = 5; carbs_g = 18; fat_g = 10; }
  if (q.includes("dessert") || q.includes("حلو") || q.includes("cake")) { calories = 380; protein_g = 6; carbs_g = 48; fat_g = 18; }
  return { dish, calories, protein_g, carbs_g, fat_g, serving:"1 typical serving (estimated)" };
}

function stripJson(text) {
  return text.replace(/```json|```/g, "").trim();
}

async function estimateFood(dish, cuisine) {
  const sys =
    "You are a precise nutrition estimation engine covering Arabian/Gulf cuisine and international cuisine. " +
    'Respond with ONLY raw JSON: {"dish":"string","calories":number,"protein_g":number,"carbs_g":number,"fat_g":number,"serving":"string"}.';
  try {
    const raw = await callClaude(sys, `Cuisine: ${cuisine}. Dish: ${dish}`);
    return JSON.parse(stripJson(raw));
  } catch {
    return localFoodEstimate(dish);
  }
}

async function generatePlan(profile, targets, lang) {
  const sys =
    "You are an AI diet planner mixing Arabian/Gulf staples with international food. " +
    'Respond with ONLY raw JSON in this exact shape: {"meals":[{"meal":"Breakfast","food":"string","calories":number,"protein_g":number,"carbs_g":number,"fat_g":number},{"meal":"Lunch","food":"string","calories":number,"protein_g":number,"carbs_g":number,"fat_g":number},{"meal":"Dinner","food":"string","calories":number,"protein_g":number,"carbs_g":number,"fat_g":number},{"meal":"Snack","food":"string","calories":number,"protein_g":number,"carbs_g":number,"fat_g":number}],"total_calories":number,"total_protein_g":number,"total_carbs_g":number,"total_fat_g":number}.';
  try {
    const raw = await callClaude(sys, `Profile: ${JSON.stringify(profile)}. Daily targets: ${JSON.stringify(targets)}. Language: ${lang}.`);
    return JSON.parse(stripJson(raw));
  } catch {
    const total = targets?.calories || 2000;
    const foods = lang === "ar"
      ? [["الفطور","بيض + خبز عربي + فاكهة"],["الغداء","كبسة دجاج + سلطة"],["العشاء","دجاج مشوي + أرز + خضار"],["وجبة خفيفة","زبادي + تمر"]]
      : [["Breakfast","Eggs + Arabic bread + fruit"],["Lunch","Chicken Kabsa + salad"],["Dinner","Grilled chicken + rice + vegetables"],["Snack","Yogurt + dates"]];
    const shares = [0.25,0.35,0.28,0.12];
    const meals = foods.map((x,i) => {
      const calories = Math.round(total * shares[i]);
      const protein_g = Math.round((targets?.protein || 120) * [0.22,0.34,0.30,0.14][i]);
      const carbs_g = Math.round((targets?.carbs || 220) * [0.28,0.38,0.25,0.09][i]);
      const fat_g = Math.round((targets?.fat || 65) * [0.22,0.36,0.28,0.14][i]);
      return { meal:x[0], food:x[1], calories, protein_g, carbs_g, fat_g };
    });
    return {
      meals,
      total_calories: meals.reduce((s,m)=>s+m.calories,0),
      total_protein_g: meals.reduce((s,m)=>s+m.protein_g,0),
      total_carbs_g: meals.reduce((s,m)=>s+m.carbs_g,0),
      total_fat_g: meals.reduce((s,m)=>s+m.fat_g,0)
    };
  }
}

async function askAssistant(history, lang) {
  const sys =
    "You are NutriAI Assistant, a helpful nutrition guide covering Arabian and international food. " +
    "Give concise, practical answers with calories/macros when relevant. You are not a doctor.";
  const content = history.map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.text}`).join("\n");
  try {
    return await callClaude(sys, content);
  } catch {
    const q = (history[history.length - 1]?.text || "").toLowerCase();
    const food = findLocalFood(q);
    if (food) {
      return lang === "ar"
        ? `التقدير التقريبي لـ ${food.dish}: ${food.calories} سعرة حرارية، بروتين ${food.protein_g}غ، كربوهيدرات ${food.carbs_g}غ، دهون ${food.fat_g}غ. الحجم: ${food.serving}.`
        : `Estimated nutrition for ${food.dish}: ${food.calories} kcal, ${food.protein_g}g protein, ${food.carbs_g}g carbs and ${food.fat_g}g fat. Serving: ${food.serving}.`;
    }
    return lang === "ar"
      ? "أستطيع مساعدتك في السعرات، الوجبات وخطط التغذية. جرّب كتابة اسم طبق مثل الكبسة أو الشاورما."
      : "I can help with calories, meals and diet planning. Try entering a food such as Kabsa, Shawarma, rice or eggs.";
  }
}

/* =========================================================
   CALCULATIONS
========================================================= */
function computeTargets(p) {
  const w = parseFloat(p.weight), h = parseFloat(p.height), a = parseFloat(p.age);
  let bmr = p.gender === "male" ? 10 * w + 6.25 * h - 5 * a + 5 : 10 * w + 6.25 * h - 5 * a - 161;
  const mult = [1.2, 1.375, 1.55, 1.725, 1.9][p.activityIdx] || 1.2;
  let tdee = bmr * mult;
  if (p.goalIdx === 0) tdee -= 400;
  if (p.goalIdx === 2 || p.goalIdx === 3) tdee += 350;
  const calories = Math.round(tdee);
  const protein = Math.round((calories * (p.goalIdx === 3 ? 0.3 : 0.25)) / 4);
  const fat = Math.round((calories * 0.28) / 9);
  const carbs = Math.round((calories - protein * 4 - fat * 9) / 4);
  return { bmr: Math.round(bmr), tdee: Math.round(tdee), calories, protein, carbs, fat };
}

const todayStr = () => new Date().toISOString().slice(0, 10);

/* =========================================================
   SMALL UI PIECES
========================================================= */
const Ring = ({ pct, size = 96, stroke = 9, color = "#D4AF37", label, value }) => {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, off = c - Math.min(pct, 1) * c;
  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#1c4038" strokeWidth={stroke} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none"
          strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round"
          transform={`rotate(-90 ${size / 2} ${size / 2})`} style={{ transition: "stroke-dashoffset .6s ease" }} />
        <text x="50%" y="50%" textAnchor="middle" dy=".3em" fill="#F3E7C9" fontSize="15" fontWeight="800">{value}</text>
      </svg>
      <span className="text-[11px] text-[#F3E7C9]/60 mt-1">{label}</span>
    </div>
  );
};

const PatternDivider = () => (
  <svg viewBox="0 0 400 24" className="w-full h-6 opacity-40" preserveAspectRatio="xMidYMid slice">
    {Array.from({ length: 20 }).map((_, i) => (
      <path key={i} transform={`translate(${i * 20},0)`} d="M10 0 L20 12 L10 24 L0 12 Z" fill="none" stroke="#D4AF37" strokeWidth="1" />
    ))}
  </svg>
);

const Plate3D = () => (
  <div className="relative flex items-center justify-center h-64 md:h-80 [perspective:1200px]">
    <div className="absolute w-52 h-52 md:w-64 md:h-64 rounded-full plate-spin [transform-style:preserve-3d]">
      <div className="absolute inset-0 rounded-full border-[10px] border-[#D4AF37]/70 shadow-[0_0_60px_rgba(212,175,55,0.25)]"
           style={{ background: "conic-gradient(from 0deg, #163832, #0f2723, #163832, #1c4038, #163832)" }} />
      <div className="absolute inset-6 rounded-full border border-[#D4AF37]/40 flex items-center justify-center">
        <span className="text-[#F3E7C9] font-semibold tracking-widest text-xs">NUTRI · AI</span>
      </div>
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="absolute left-1/2 top-1/2 w-1.5 h-1.5 rounded-full bg-[#D4AF37]"
             style={{ transform: `rotate(${i * 30}deg) translate(0, -100px)` }} />
      ))}
    </div>
  </div>
);

const Card = ({ children, className = "" }) => (
  <div className={`bg-[#0F2E29] border border-[#D4AF37]/20 rounded-2xl card-hover ${className}`}>{children}</div>
);

/* =========================================================
   MAIN APP
========================================================= */
export default function App() {
  const [lang, setLang] = useState("en");
  const [view, setView] = useState("home");
  const [loaded, setLoaded] = useState(false);
  const [profile, setProfile] = useState(null);
  const [targets, setTargets] = useState(null);
  const [today, setToday] = useState({ date: todayStr(), items: [], water_ml: 0 });
  const [savedPlan, setSavedPlan] = useState(null);
  const [saveTimer, setSaveTimer] = useState(null);

  const t = T[lang];
  const isAr = lang === "ar";

  /* ---- persistence ---- */
  useEffect(() => {
    (async () => {
      try {
        const raw = window.storage?.get
          ? (await window.storage.get("nutriai-state", false))?.value
          : localStorage.getItem("nutriai-state");
        if (raw) {
          const s = JSON.parse(raw);
          setLang(s.lang || "en");
          setProfile(s.profile || null);
          setTargets(s.targets || null);
          setSavedPlan(s.savedPlan || null);
          if (s.today && s.today.date === todayStr()) setToday(s.today);
          else setToday({ date: todayStr(), items: [], water_ml: 0 });
        }
      } catch (e) {
        /* first run, no saved state */
      }
      setLoaded(true);
    })();
  }, []);

  const persist = useCallback((partial) => {
    clearTimeout(saveTimer);
    const timer = setTimeout(async () => {
      try {
        const state = { lang, profile, targets, savedPlan, today, ...partial };
        const value = JSON.stringify(state);
        if (window.storage?.set) await window.storage.set("nutriai-state", value, false);
        else localStorage.setItem("nutriai-state", value);
      } catch (e) { /* best effort */ }
    }, 300);
    setSaveTimer(timer);
    // eslint-disable-next-line
  }, [lang, profile, targets, savedPlan, today]);

  useEffect(() => { if (loaded) persist({}); }, [lang, profile, targets, savedPlan, today, loaded]); // eslint-disable-line

  const scrollTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  const goto = (v) => {
    if (v === "dash" && !profile) { setView("onboard"); scrollTop(); return; }
    setView(v); scrollTop();
  };

  const addFood = (item, meal) => {
    setToday((prev) => ({ ...prev, items: [...prev.items, { ...item, meal, id: Date.now() }] }));
  };

  const totals = today.items.reduce(
    (acc, i) => ({ cal: acc.cal + (i.calories || 0), p: acc.p + (i.protein_g || 0), c: acc.c + (i.carbs_g || 0), f: acc.f + (i.fat_g || 0) }),
    { cal: 0, p: 0, c: 0, f: 0 }
  );

  if (!loaded) return <div className="min-h-screen flex items-center justify-center bg-[#0B211E] text-[#F3E7C9]">…</div>;

  return (
    <div dir={t.dir} className={`min-h-screen w-full ${isAr ? "font-arabic" : "font-latin"}`} style={{ background: "#0B211E", color: "#F3E7C9" }}>
      <GlobalStyle />
      <Header t={t} isAr={isAr} lang={lang} setLang={setLang} goto={goto} view={view} />

      {view === "home" && <Home t={t} goto={goto} />}
      {view === "onboard" && (
        <Onboard t={t} lang={lang} onSubmit={(p) => { const tg = computeTargets(p); setProfile(p); setTargets(tg); setView("dash"); scrollTop(); }} />
      )}
      {view === "dash" && profile && <Dashboard t={t} profile={profile} targets={targets} today={today} totals={totals} setToday={setToday} goto={goto} />}
      {view === "calc" && <Calculator t={t} lang={lang} onAdd={addFood} />}
      {view === "plan" && (
        <PlanView t={t} lang={lang} profile={profile} targets={targets} savedPlan={savedPlan} setSavedPlan={setSavedPlan} goto={goto} />
      )}
      {view === "assistant" && <Assistant t={t} lang={lang} />}
      {view === "pricing" && <Pricing t={t} />}

      <PatternDivider />
      <footer className="max-w-6xl mx-auto px-5 py-8 text-center">
        <div className="font-extrabold text-[#D4AF37] mb-1">{t.brand}</div>
        <p className="text-[11px] text-[#F3E7C9]/40 max-w-md mx-auto mb-2">{t.footerNote}</p>
        <p className="text-[11px] text-[#F3E7C9]/30">© 2026 {t.brand} · AI nutrition estimates · Secure backend recommended for production</p>
      </footer>
    </div>
  );
}

/* =========================================================
   STYLE
========================================================= */
const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Tajawal:wght@400;500;700&display=swap');
    .font-latin { font-family: 'Cairo', sans-serif; }
    .font-arabic { font-family: 'Tajawal', 'Cairo', sans-serif; }
    .plate-spin { animation: spin3d 18s linear infinite; }
    @keyframes spin3d { from { transform: rotateY(0deg) rotateX(8deg);} to { transform: rotateY(360deg) rotateX(8deg);} }
    @media (prefers-reduced-motion: reduce) { .plate-spin { animation: none; } }
    .card-hover { transition: transform .25s ease, box-shadow .25s ease; }
    .card-hover:hover { transform: translateY(-3px); box-shadow: 0 18px 40px -12px rgba(0,0,0,0.5); }
    .gold-btn { background: linear-gradient(135deg,#E7C468,#C9962F); color:#0B211E; }
    input, select, textarea { color-scheme: dark; }
  `}</style>
);

const inputCls = "w-full bg-[#0B211E] border border-[#D4AF37]/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#D4AF37] placeholder:text-[#F3E7C9]/40";
const labelCls = "block text-xs text-[#F3E7C9]/60 mb-1.5";
const pillBtn = (active) => `px-3 py-2 rounded-lg text-xs font-semibold border transition ${active ? "gold-btn border-transparent" : "border-[#D4AF37]/30 text-[#F3E7C9]/70"}`;

/* =========================================================
   HEADER
========================================================= */
function Header({ t, isAr, lang, setLang, goto, view }) {
  const [open, setOpen] = useState(false);
  const items = [["home", t.nav.home], ["dash", t.nav.dash], ["calc", t.nav.calc], ["plan", t.nav.plan], ["assistant", t.nav.assistant], ["pricing", t.nav.pricing]];
  return (
    <header className="sticky top-0 z-30 backdrop-blur bg-[#0B211E]/90 border-b border-[#D4AF37]/20">
      <div className="max-w-6xl mx-auto px-5 py-3.5 flex items-center justify-between">
        <button onClick={() => goto("home")} className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full flex items-center justify-center gold-btn font-extrabold">N</div>
          <div className="text-start">
            <div className="font-extrabold text-lg leading-none">{t.brand}</div>
            <div className="text-[9px] tracking-widest uppercase text-[#D4AF37]/80">{t.tagline.slice(0, 22)}</div>
          </div>
        </button>
        <nav className="hidden md:flex items-center gap-6 text-sm text-[#F3E7C9]/85">
          {items.map(([k, label]) => (
            <button key={k} onClick={() => goto(k)} className={`hover:text-[#D4AF37] transition ${view === k ? "text-[#D4AF37]" : ""}`}>{label}</button>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <button onClick={() => setLang(isAr ? "en" : "ar")} className="text-xs font-semibold px-3 py-1.5 rounded-full border border-[#D4AF37]/50 hover:bg-[#D4AF37]/10 transition">
            {t.langToggle}
          </button>
          <button onClick={() => setOpen(!open)} className="md:hidden text-xs px-2.5 py-1.5 rounded-lg border border-[#D4AF37]/40">☰</button>
        </div>
      </div>
      {open && (
        <div className="md:hidden px-5 pb-3 flex flex-wrap gap-2">
          {items.map(([k, label]) => (
            <button key={k} onClick={() => { goto(k); setOpen(false); }} className={pillBtn(view === k)}>{label}</button>
          ))}
        </div>
      )}
    </header>
  );
}

/* =========================================================
   HOME
========================================================= */
function Home({ t, goto }) {
  return (
    <>
      <section className="max-w-6xl mx-auto px-5 pt-12 pb-6 grid md:grid-cols-2 gap-10 items-center">
        <div>
          <h1 className="text-3xl md:text-5xl font-extrabold leading-tight mb-4">{t.heroTitle}</h1>
          <p className="text-[#F3E7C9]/75 text-sm md:text-base mb-7 max-w-md">{t.heroSub}</p>
          <div className="flex flex-wrap gap-3">
            <button onClick={() => goto("onboard")} className="gold-btn px-5 py-3 rounded-xl font-bold text-sm">{t.heroCta}</button>
            <button onClick={() => goto("pricing")} className="px-5 py-3 rounded-xl font-bold text-sm border border-[#D4AF37]/50 hover:bg-[#D4AF37]/10 transition">{t.heroCta2}</button>
          </div>
        </div>
        <Plate3D />
      </section>
      <PatternDivider />
      <section className="max-w-6xl mx-auto px-5 py-14">
        <h2 className="text-2xl font-extrabold text-center mb-8">{t.features.title}</h2>
        <div className="grid md:grid-cols-3 gap-5">
          {t.features.items.map((f, i) => (
            <Card key={i} className="p-6">
              <div className="w-10 h-10 rounded-lg gold-btn flex items-center justify-center font-extrabold mb-3">{i + 1}</div>
              <div className="font-bold mb-1.5">{f.t}</div>
              <div className="text-sm text-[#F3E7C9]/70">{f.d}</div>
            </Card>
          ))}
        </div>
      </section>
      <section className="max-w-6xl mx-auto px-5 py-6">
        <div className="grid md:grid-cols-3 gap-4">
          {[IMG.kabsa, IMG.intl, IMG.sweets].map((src, i) => (
            <img key={i} src={src} alt="" loading="lazy" className="w-full h-40 object-cover rounded-2xl border border-[#D4AF37]/20" onError={(e) => { e.currentTarget.style.display = "none"; }} />
          ))}
        </div>
      </section>
      <section className="max-w-3xl mx-auto px-5 py-14">
        <h2 className="text-2xl font-extrabold text-center mb-8">{t.faq.title}</h2>
        <div className="space-y-3">
          {t.faq.items.map((f, i) => (
            <details key={i} className="bg-[#0F2E29] border border-[#D4AF37]/20 rounded-xl p-4">
              <summary className="font-semibold cursor-pointer">{f.q}</summary>
              <p className="text-sm text-[#F3E7C9]/70 mt-2">{f.a}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}

/* =========================================================
   ONBOARDING
========================================================= */
function Onboard({ t, lang, onSubmit }) {
  const o = t.onboard;
  const [f, setF] = useState({
    name: "", age: "28", gender: "male", height: "175", weight: "75",
    activityIdx: 1, goalIdx: 0, targetWeight: "70", dietIdx: 0, allergies: "", meals: "4",
  });
  const upd = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const submit = (e) => {
    e.preventDefault();
    onSubmit({
      name: f.name || (lang === "ar" ? "صديقي" : "Friend"), age: f.age, gender: f.gender,
      height: f.height, weight: f.weight, activityIdx: f.activityIdx, goalIdx: f.goalIdx,
      targetWeight: f.targetWeight, diet: o.dietOpts[f.dietIdx], allergies: f.allergies, meals: f.meals,
    });
  };
  return (
    <section className="max-w-2xl mx-auto px-5 py-14">
      <h2 className="text-2xl font-extrabold mb-1 text-center">{o.title}</h2>
      <p className="text-sm text-[#F3E7C9]/60 text-center mb-8">{o.sub}</p>
      <form onSubmit={submit} className="bg-[#0F2E29] border border-[#D4AF37]/20 rounded-2xl p-6 md:p-8 grid sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2"><label className={labelCls}>{o.name}</label><input className={inputCls} value={f.name} onChange={(e) => upd("name", e.target.value)} /></div>
        <div><label className={labelCls}>{o.age}</label><input type="number" className={inputCls} value={f.age} onChange={(e) => upd("age", e.target.value)} /></div>
        <div>
          <label className={labelCls}>{o.gender}</label>
          <div className="flex gap-2">
            <button type="button" onClick={() => upd("gender", "male")} className={pillBtn(f.gender === "male") + " flex-1"}>{o.male}</button>
            <button type="button" onClick={() => upd("gender", "female")} className={pillBtn(f.gender === "female") + " flex-1"}>{o.female}</button>
          </div>
        </div>
        <div><label className={labelCls}>{o.height}</label><input type="number" className={inputCls} value={f.height} onChange={(e) => upd("height", e.target.value)} /></div>
        <div><label className={labelCls}>{o.weight}</label><input type="number" className={inputCls} value={f.weight} onChange={(e) => upd("weight", e.target.value)} /></div>
        <div className="sm:col-span-2">
          <label className={labelCls}>{o.activity}</label>
          <div className="flex flex-wrap gap-2">
            {o.activityOpts.map((a, i) => <button type="button" key={i} onClick={() => upd("activityIdx", i)} className={pillBtn(f.activityIdx === i)}>{a}</button>)}
          </div>
        </div>
        <div className="sm:col-span-2">
          <label className={labelCls}>{o.goal}</label>
          <div className="flex flex-wrap gap-2">
            {o.goalOpts.map((g, i) => <button type="button" key={i} onClick={() => upd("goalIdx", i)} className={pillBtn(f.goalIdx === i)}>{g}</button>)}
          </div>
        </div>
        <div><label className={labelCls}>{o.targetWeight}</label><input type="number" className={inputCls} value={f.targetWeight} onChange={(e) => upd("targetWeight", e.target.value)} /></div>
        <div><label className={labelCls}>{o.meals}</label><input type="number" min="2" max="6" className={inputCls} value={f.meals} onChange={(e) => upd("meals", e.target.value)} /></div>
        <div className="sm:col-span-2">
          <label className={labelCls}>{o.diet}</label>
          <div className="flex flex-wrap gap-2">
            {o.dietOpts.map((d, i) => <button type="button" key={i} onClick={() => upd("dietIdx", i)} className={pillBtn(f.dietIdx === i)}>{d}</button>)}
          </div>
        </div>
        <div className="sm:col-span-2"><label className={labelCls}>{o.allergies}</label><input className={inputCls} placeholder={o.allergiesPh} value={f.allergies} onChange={(e) => upd("allergies", e.target.value)} /></div>
        <button type="submit" className="sm:col-span-2 gold-btn py-3 rounded-lg font-bold text-sm mt-2">{o.submit}</button>
      </form>
    </section>
  );
}

/* =========================================================
   DASHBOARD
========================================================= */
function Dashboard({ t, profile, targets, today, totals, setToday, goto }) {
  const d = t.dash;
  const remaining = Math.max(targets.calories - totals.cal, 0);
  const addWater = (ml) => setToday((p) => ({ ...p, water_ml: Math.min(p.water_ml + ml, 4000) }));
  const glasses = Math.round(today.water_ml / 250);

  return (
    <section className="max-w-6xl mx-auto px-5 py-10">
      <h2 className="text-2xl font-extrabold mb-6">{d.title} — {profile.name}</h2>
      <div className="grid md:grid-cols-3 gap-5 mb-6">
        <Card className="p-6 md:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-3xl font-extrabold text-[#D4AF37]">{Math.round(totals.cal)}</div>
              <div className="text-xs text-[#F3E7C9]/60">{d.consumed} · {d.goal} {targets.calories}</div>
            </div>
            <div className="text-end">
              <div className="text-xl font-extrabold">{remaining}</div>
              <div className="text-xs text-[#F3E7C9]/60">{d.remaining}</div>
            </div>
          </div>
          <div className="w-full h-2.5 rounded-full bg-[#0B211E] overflow-hidden">
            <div className="h-full gold-btn" style={{ width: `${Math.min((totals.cal / targets.calories) * 100, 100)}%`, transition: "width .5s ease" }} />
          </div>
          <div className="flex justify-around mt-6">
            <Ring pct={totals.p / targets.protein} value={`${Math.round(totals.p)}g`} label={d.protein} color="#8FBF9F" />
            <Ring pct={totals.c / targets.carbs} value={`${Math.round(totals.c)}g`} label={d.carbs} color="#D4AF37" />
            <Ring pct={totals.f / targets.fat} value={`${Math.round(totals.f)}g`} label={d.fat} color="#E28B67" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="font-bold mb-3">{d.water}</div>
          <div className="text-2xl font-extrabold text-[#D4AF37] mb-1">{glasses} / 8</div>
          <div className="text-xs text-[#F3E7C9]/60 mb-4">{d.glasses}</div>
          <div className="w-full h-2.5 rounded-full bg-[#0B211E] overflow-hidden mb-4">
            <div className="h-full bg-[#5B9BD5]" style={{ width: `${Math.min((glasses / 8) * 100, 100)}%`, transition: "width .5s ease" }} />
          </div>
          <div className="flex gap-2">
            <button onClick={() => addWater(250)} className="flex-1 border border-[#D4AF37]/40 rounded-lg py-2 text-xs font-semibold hover:bg-[#D4AF37]/10">+250ml</button>
            <button onClick={() => addWater(500)} className="flex-1 border border-[#D4AF37]/40 rounded-lg py-2 text-xs font-semibold hover:bg-[#D4AF37]/10">+500ml</button>
          </div>
          <div className="mt-5 pt-4 border-t border-[#D4AF37]/15 text-xs text-[#F3E7C9]/60 space-y-1">
            <div>{d.bmr}: <span className="text-[#F3E7C9]">{targets.bmr} kcal</span></div>
            <div>{d.tdee}: <span className="text-[#F3E7C9]">{targets.tdee} kcal</span></div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="font-bold">{d.mealsToday}</div>
          <button onClick={() => goto("calc")} className="text-xs gold-btn px-3 py-1.5 rounded-full font-bold">+ {t.calc.title}</button>
        </div>
        {today.items.length === 0 ? (
          <p className="text-sm text-[#F3E7C9]/50">{d.noMeals}</p>
        ) : (
          <div className="space-y-2">
            {today.items.map((it) => (
              <div key={it.id} className="flex items-center justify-between text-sm bg-[#0B211E] rounded-lg px-4 py-2.5">
                <div><span className="text-[#D4AF37] font-semibold">{it.meal}</span> — {it.dish}</div>
                <div className="text-[#F3E7C9]/70">{Math.round(it.calories)} kcal</div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </section>
  );
}

/* =========================================================
   AI CALCULATOR
========================================================= */
function Calculator({ t, lang, onAdd }) {
  const c = t.calc;
  const [dish, setDish] = useState("");
  const [cuisine, setCuisine] = useState("arabian");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [meal, setMeal] = useState(0);
  const [added, setAdded] = useState(false);

  const run = async (custom) => {
    const q = custom ?? dish;
    if (!q.trim()) return;
    setLoading(true); setError(""); setResult(null); setAdded(false);
    try {
      const r = await estimateFood(q, cuisine === "arabian" ? "Arabian/Gulf" : "International");
      setResult(r);
    } catch (e) { setError(c.errorGeneric); }
    finally { setLoading(false); }
  };

  return (
    <section className="max-w-2xl mx-auto px-5 py-14">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-extrabold mb-2">{c.title}</h2>
        <p className="text-sm text-[#F3E7C9]/70">{c.sub}</p>
      </div>
      <Card className="p-5 md:p-8">
        <div className="flex gap-2 mb-4">
          <button onClick={() => setCuisine("arabian")} className={pillBtn(cuisine === "arabian") + " flex-1 py-2.5"}>{c.arabian}</button>
          <button onClick={() => setCuisine("intl")} className={pillBtn(cuisine === "intl") + " flex-1 py-2.5"}>{c.intl}</button>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <input value={dish} onChange={(e) => setDish(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} placeholder={c.placeholder} className={inputCls + " flex-1"} />
          <button onClick={() => run()} disabled={loading} className="gold-btn px-5 py-3 rounded-lg font-bold text-sm whitespace-nowrap disabled:opacity-60">
            {loading ? c.loading : c.button}
          </button>
        </div>
        <div className="flex flex-wrap gap-2 mt-4">
          <span className="text-xs text-[#F3E7C9]/50">{c.tryExamples}</span>
          {c.examples.map((ex) => <button key={ex} onClick={() => { setDish(ex); run(ex); }} className="text-xs px-2.5 py-1 rounded-full border border-[#D4AF37]/30 text-[#F3E7C9]/70 hover:border-[#D4AF37] hover:text-[#D4AF37] transition">{ex}</button>)}
        </div>
        {error && <div className="mt-5 text-sm text-red-300">{error}</div>}
        {result && (
          <div className="mt-6 border-t border-[#D4AF37]/20 pt-5">
            <div className="flex items-baseline justify-between mb-4">
              <h3 className="font-bold text-[#D4AF37]">{c.resultTitle}</h3>
              <span className="text-xs text-[#F3E7C9]/50">{result.serving || c.serving}</span>
            </div>
            <div className="grid grid-cols-4 gap-2 text-center mb-5">
              <div className="bg-[#0B211E] rounded-lg py-3"><div className="text-lg font-extrabold text-[#D4AF37]">{Math.round(result.calories)}</div><div className="text-[10px] text-[#F3E7C9]/60 mt-1">{c.calories}</div></div>
              <div className="bg-[#0B211E] rounded-lg py-3"><div className="text-lg font-extrabold">{Math.round(result.protein_g)}g</div><div className="text-[10px] text-[#F3E7C9]/60 mt-1">{t.dash.protein}</div></div>
              <div className="bg-[#0B211E] rounded-lg py-3"><div className="text-lg font-extrabold">{Math.round(result.carbs_g)}g</div><div className="text-[10px] text-[#F3E7C9]/60 mt-1">{t.dash.carbs}</div></div>
              <div className="bg-[#0B211E] rounded-lg py-3"><div className="text-lg font-extrabold">{Math.round(result.fat_g)}g</div><div className="text-[10px] text-[#F3E7C9]/60 mt-1">{t.dash.fat}</div></div>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-center">
              <select value={meal} onChange={(e) => setMeal(+e.target.value)} className={inputCls + " sm:w-40"}>
                {c.mealOpts.map((m, i) => <option key={i} value={i}>{m}</option>)}
              </select>
              <button onClick={() => { onAdd(result, c.mealOpts[meal]); setAdded(true); }} className="gold-btn px-4 py-2.5 rounded-lg font-bold text-sm">
                {added ? c.added : c.addToday}
              </button>
            </div>
            <p className="text-[10px] text-[#F3E7C9]/40 mt-3">{c.note}</p>
          </div>
        )}
      </Card>
    </section>
  );
}

/* =========================================================
   DIET PLAN
========================================================= */
function PlanView({ t, lang, profile, targets, savedPlan, setSavedPlan, goto }) {
  const p = t.plan;
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState(savedPlan);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(!!savedPlan);

  if (!profile) {
    return (
      <section className="max-w-lg mx-auto px-5 py-20 text-center">
        <p className="text-sm text-[#F3E7C9]/70 mb-5">{p.needProfile}</p>
        <button onClick={() => goto("onboard")} className="gold-btn px-5 py-3 rounded-lg font-bold text-sm">{p.goProfile}</button>
      </section>
    );
  }

  const run = async () => {
    setLoading(true); setError(""); setSaved(false);
    try {
      const r = await generatePlan(profile, targets, lang);
      setPlan(r);
    } catch (e) { setError(t.calc.errorGeneric); }
    finally { setLoading(false); }
  };

  return (
    <section className="max-w-3xl mx-auto px-5 py-14">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-extrabold mb-2">{p.title}</h2>
        <p className="text-sm text-[#F3E7C9]/70">{p.sub}</p>
      </div>

      {!plan && (
        <div className="text-center">
          <button onClick={run} disabled={loading} className="gold-btn px-6 py-3.5 rounded-xl font-bold text-sm disabled:opacity-60">
            {loading ? p.loading : p.generate}
          </button>
        </div>
      )}

      {error && <div className="mt-5 text-sm text-red-300 text-center">{error}</div>}

      {plan && (
        <>
          <div className="grid sm:grid-cols-2 gap-3 mb-6">
            {plan.meals.map((m, i) => (
              <Card key={i} className="p-5">
                <div className="text-xs font-bold text-[#D4AF37] mb-1">{m.meal}</div>
                <div className="font-semibold mb-2">{m.food}</div>
                <div className="flex gap-3 text-xs text-[#F3E7C9]/60">
                  <span>{Math.round(m.calories)} kcal</span><span>{Math.round(m.protein_g)}g P</span><span>{Math.round(m.carbs_g)}g C</span><span>{Math.round(m.fat_g)}g F</span>
                </div>
              </Card>
            ))}
          </div>
          <Card className="p-5 flex flex-wrap items-center justify-between gap-3 mb-6">
            <div className="text-sm">
              <span className="text-[#D4AF37] font-bold">{p.dailyTotal}:</span> {Math.round(plan.total_calories)} kcal · {Math.round(plan.total_protein_g)}g P · {Math.round(plan.total_carbs_g)}g C · {Math.round(plan.total_fat_g)}g F
            </div>
          </Card>
          <div className="flex flex-wrap gap-3 justify-center">
            <button onClick={run} disabled={loading} className="border border-[#D4AF37]/40 px-5 py-2.5 rounded-lg font-bold text-sm hover:bg-[#D4AF37]/10 disabled:opacity-60">
              {loading ? p.loading : p.regenerate}
            </button>
            <button onClick={() => { setSavedPlan(plan); setSaved(true); }} className="gold-btn px-5 py-2.5 rounded-lg font-bold text-sm">
              {saved ? p.saved : p.save}
            </button>
          </div>
        </>
      )}
      <p className="text-[10px] text-[#F3E7C9]/40 mt-6 text-center">{t.calc.note}</p>
    </section>
  );
}

/* =========================================================
   AI ASSISTANT
========================================================= */
function Assistant({ t, lang }) {
  const a = t.assistant;
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async (text) => {
    const q = text ?? input;
    if (!q.trim() || loading) return;
    const next = [...messages, { role: "user", text: q }];
    setMessages(next); setInput(""); setLoading(true);
    try {
      const reply = await askAssistant(next, lang);
      setMessages([...next, { role: "assistant", text: reply }]);
    } catch (e) {
      setMessages([...next, { role: "assistant", text: t.calc.errorGeneric }]);
    } finally { setLoading(false); }
  };

  return (
    <section className="max-w-2xl mx-auto px-5 py-14">
      <div className="text-center mb-6">
        <h2 className="text-2xl md:text-3xl font-extrabold mb-2">{a.title}</h2>
        <p className="text-sm text-[#F3E7C9]/70">{a.sub}</p>
      </div>
      <Card className="p-5 flex flex-col h-[480px]">
        <div className="flex-1 overflow-y-auto space-y-3 pe-1">
          {messages.length === 0 && (
            <div className="flex flex-wrap gap-2 justify-center mt-6">
              {a.starterQs.map((q) => <button key={q} onClick={() => send(q)} className="text-xs px-3 py-1.5 rounded-full border border-[#D4AF37]/30 hover:border-[#D4AF37] hover:text-[#D4AF37] transition">{q}</button>)}
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`max-w-[85%] rounded-xl px-4 py-2.5 text-sm ${m.role === "user" ? "ms-auto gold-btn" : "bg-[#0B211E] border border-[#D4AF37]/15"}`}>
              {m.text}
            </div>
          ))}
          {loading && <div className="bg-[#0B211E] border border-[#D4AF37]/15 rounded-xl px-4 py-2.5 text-sm w-fit text-[#F3E7C9]/60">…</div>}
          <div ref={endRef} />
        </div>
        <div className="flex gap-2 mt-4 pt-4 border-t border-[#D4AF37]/15">
          <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder={a.placeholder} className={inputCls + " flex-1"} />
          <button onClick={() => send()} disabled={loading} className="gold-btn px-4 py-2.5 rounded-lg font-bold text-sm disabled:opacity-60">{a.send}</button>
        </div>
      </Card>
      <p className="text-[10px] text-[#F3E7C9]/40 mt-4 text-center">{a.safety}</p>
    </section>
  );
}

/* =========================================================
   PRICING
========================================================= */
function Pricing({ t }) {
  const pr = t.pricing;
  const plans = [pr.free, pr.premium, pr.plus];
  const [selected, setSelected] = useState(null);
  return (
    <section className="max-w-6xl mx-auto px-5 py-16">
      <div className="text-center max-w-xl mx-auto mb-10">
        <h2 className="text-2xl md:text-3xl font-extrabold mb-3">{pr.title}</h2>
        <p className="text-[#F3E7C9]/70 text-sm">{pr.sub}</p>
      </div>
      <div className="grid md:grid-cols-3 gap-5">
        {plans.map((plan, i) => (
          <div key={i} className={`relative rounded-2xl p-6 flex flex-col card-hover ${i === 1 ? "border-2 border-[#D4AF37] bg-[#12352F]" : "border border-[#D4AF37]/20 bg-[#0F2E29]"}`}>
            {i === 1 && <span className="absolute -top-3 start-1/2 -translate-x-1/2 gold-btn text-[10px] font-bold px-3 py-1 rounded-full">{pr.recommended}</span>}
            <div className="font-extrabold text-lg mb-1">{plan.name}</div>
            <div className="text-xs text-[#F3E7C9]/50 mb-4">{plan.desc}</div>
            <div className="mb-5">
              <span className="text-3xl font-extrabold text-[#D4AF37]">{plan.price}</span>
              {i > 0 && <span className="text-xs text-[#F3E7C9]/50"> {pr.perMonth}</span>}
            </div>
            <ul className="space-y-2.5 text-sm mb-6 flex-1">
              {plan.features.map((f, j) => (
                <li key={j} className="flex items-start gap-2"><span className="text-[#D4AF37] mt-0.5">✦</span><span className="text-[#F3E7C9]/85">{f}</span></li>
              ))}
            </ul>
            <button
              onClick={() => setSelected(i)}
              className={`w-full py-2.5 rounded-lg font-bold text-sm ${i === 1 ? "gold-btn" : "border border-[#D4AF37]/40 hover:bg-[#D4AF37]/10 transition"}`}
            >{plan.cta}</button>
          </div>
        ))}
      </div>
      {selected !== null && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-5" onClick={() => setSelected(null)}>
          <div className="max-w-md w-full bg-[#0F2E29] border border-[#D4AF37]/30 rounded-2xl p-7 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="text-[#D4AF37] text-xs font-bold uppercase tracking-widest mb-2">NutriAI Subscription</div>
            <h3 className="text-2xl font-extrabold mb-2">{plans[selected].name}</h3>
            <p className="text-sm text-[#F3E7C9]/70 mb-5">{plans[selected].price} {selected > 0 ? pr.perMonth : ""}</p>
            <div className="bg-[#0B211E] rounded-xl p-4 text-sm text-[#F3E7C9]/75 mb-5">
              {selected === 0
                ? "Your free plan is ready. No payment is required."
                : "Payment integration is ready to connect to your Saudi payment provider. Do not enter card details until a secure payment gateway is connected."}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setSelected(null)} className="flex-1 py-2.5 rounded-lg border border-[#D4AF37]/30">Close</button>
              {selected === 0 && <button onClick={() => setSelected(null)} className="flex-1 py-2.5 rounded-lg gold-btn font-bold">Continue</button>}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
